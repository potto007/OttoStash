# Changelog

Versions 3.0.11 and below are AzuAutoStore's release history, kept below exactly as
Azumatt wrote it.

## 3.6.4

- Rebuilt against Valheim 1.0.21. Every Harmony patch target still resolves in this build, and nothing else changed.

## 3.6.3

- Republished 3.6.2 under a new version number. Nothing else changed.

## 3.6.2

- Rebuilt against Valheim 1.0.20. Every Harmony patch target still resolves in this build, and nothing else changed.

## 3.6.1

- Rewrote the README and this changelog. The code is unchanged from 3.6.0, but a server
  and its clients still have to run the same version, so update them together.

## 3.6.0

This release brings Recycle_N_Reclaim's reclaiming and AzuCraftyBoxes' crafting from
chests into OttoStash.

### Setting names

- Every section and setting now uses the PascalCase spelling the new sections use. The
  numbered sections lose their numbers, so `1 - General` is now `General`, `1.5 - Fish`
  is `Fish`, `2 - Shortcuts` is `Shortcuts`, `3 - Favoriting` is `Favoriting` and
  `4 - Armor Stands` is `ArmorStands`. Keys lose their spaces, so `Player Range` is now
  `PlayerRange`.
- Your values carry over. On the first run OttoStash renames the settings in
  `potto007.OttoStash.cfg` before it reads them, and a config carried over from
  AzuAutoStore goes through the same rename. The file is backed up first and put back if
  the rename fails.
- If you ran 3.2.0, your config may hold a setting under both spellings, and OttoStash
  keeps the spaced one that 3.2.1 through 3.5.1 wrote.

### Reclaiming, from Recycle_N_Reclaim

- A Reclaim tab at every crafting station turns items back into their resources at
  `RecyclingRate`, and an item that cannot be reclaimed says why. `Ctrl+Z` undoes the last
  reclaim within 20 seconds.
- Reclaim All on an open container, inventory discard with `Delete` while dragging, and
  trash marking: hold `X`, click slots, then middle-click to discard them all. Discard and
  bulk trash are admin-only by default.
- `ShowRecycleYieldInTooltip` adds the reclaim yield to item tooltips.
- Epic Loot enchanting materials and Jewelcrafting gems come back too.
- `potto007.OttoStash.Reclaim.yml` holds the reclaim rules, in Recycle_N_Reclaim's
  exclude-list format.
- Coming from Recycle_N_Reclaim: on the first run, its settings are copied into the new
  `Reclaim`, `ReclaimUI`, `Discard`, `Trash` and `ReclaimDebug` sections of
  `potto007.OttoStash.cfg`, and its exclude lists to `potto007.OttoStash.Reclaim.yml`. While
  Recycle_N_Reclaim is still installed, OttoStash leaves reclaiming and trash marking to it
  and copies its settings and exclude lists again on every start, so a reclaim setting
  changed in OttoStash is overwritten until Recycle_N_Reclaim is removed.
- Changes from Recycle_N_Reclaim 1.4.5:
  - Trash marking works again. On Valheim 1.0 the click picked the item up before
    Recycle_N_Reclaim could mark the slot, so nothing was ever marked.
  - Discarding with `Delete` now clears the drag. Before, pressing `Delete` again with
    nothing dragged could discard the same amount from that stack a second time.
  - Bulk trashing obeys `Discard.LockToAdmin` and `Discard.Enabled`. It used to return
    resources even where inventory discard was locked to admins.
  - Two identical Jewelcrafting gems on one item come back as two gems. They used to fail.
  - Discarded resources that do not fit in your inventory and drop to the ground are now
    separate items, where they used to be one item shared between the drops.
  - `ReclaimTabEnabled` (formerly `EnableExperimentalCraftingTabUI`) also hides the tab
    the first time it would appear.
  - Trash marks last only while the modifier is held, which is how they effectively
    behaved already, and they are no longer written to a per-player file.
  - Middle-click with the trash modifier held no longer stores the hovered item as well.
  - There is no Auga support and no extra version handshake, so a client without
    OttoStash can still join a server that has it.
- Fixed: coming from AzuAutoStore, the first run overwrote the carried-over settings with
  defaults. OttoStash now reads them after the copy.
- The reclaim features are translated into Chinese, French, German, Japanese, Korean,
  Russian and Spanish.

### Crafting from chests, from AzuCraftyBoxes

- Crafting and building take the materials you lack from containers within `PullRange`,
  kg drawers, and the backpacks and gem bags you carry. Requirement lists show
  `have/need`, and the build menu shows how many of a piece you can build.
- A `pull:` block on a container or crafting station in `potto007.OttoStash.yml` keeps
  items from being pulled, separately from the store rules.
- `LeaveOneItem`, a personal on/off hotkey (`Alt+O`) with a status icon, and Epic Loot's
  enchanting table drawing from the chests.
- Coming from AzuCraftyBoxes: on the first run, its settings are copied into the new
  `CraftFromChests` section and its container rules are merged into
  `potto007.OttoStash.yml` as pull blocks. While AzuCraftyBoxes, CraftFromContainers or
  CFCMod is installed, OttoStash leaves crafting from chests to it.
- Changes from AzuCraftyBoxes 1.8.19:
  - Use-to-fill on smelters, kilns, fires, ovens, fermenters, shield generators and
    ballistas is left out, because OttoFuel already covers those.
  - Spending obeys the pull rules. An excluded item used to be counted out and spent anyway.
  - A one-ingredient recipe spends from the chests only when the craft succeeds, and only
    for that recipe.
  - Taking from a chest claims its ownership first, so the change is saved.

## 3.5.1

- Rebuilt against Valheim 1.0.17. Every Harmony patch target still resolves in this build, and nothing else changed.

## 3.5.0

- Armor stands open a panel. Use on a stand shows your inventory beside the stand's
  slots, drawn as a figure, where you can drag gear on or off, Ctrl-click to move it in
  one go, or use Take All to empty the stand into your bag. Nothing is thrown on the
  ground any more, and the hotbar keys still attach the vanilla way. `Armor Stand Panel`
  turns the panel off.

## 3.4.1

- Backpacks now take the last unit of a stack from the store hotkey. The bulk path used
  to stop one short, while the single-item path did not.
- An item favorited both by name and by slot now gets its own tooltip text. That branch
  could never be reached before.
- The Makail drawer refusal message names the item again.
- Internal: the code is reorganised into feature classes under `Storing/` and
  `Favoriting/`, the four store targets share one item filter, and the Debug
  configuration builds again.

## 3.4.0

Multiplayer fixes, written fresh for this release.

- Chests that were already loaded when you spawn become autostore targets straight
  away, so you no longer have to open each one after joining a server.
- The pause toggle applies once per chest, even when the game initialises a chest
  more than once.
- A container carried by another player or a creature is never treated as a chest, so
  pressing the store hotkey near another player no longer blanks their screen.
- The store hotkey, single-item store and ground pickup leave a chest alone while
  another player has it open, and OttoStash never takes that chest over. Chests are
  always released after a store, even if something goes wrong partway through.
- The store hotkey and single-item store now run in one pass, in one frame, and
  report a single "Stored N items" total.
- A chest only glows when something actually went into it.
- A stack now tops up a chest that has room for less than half of it. Before, that
  chest was skipped and the whole stack stayed with you.
- Adds an off-runtime unit test suite under `tests/` that covers the store pass,
  the chest rules, the pause handler and the stack moves.

## 3.3.2

- Rebuilt against Valheim 1.0.16. Every Harmony patch target still resolves in this build, and nothing else changed.

## v3.3.1

- Rebuilt against Valheim 1.0.15. Every Harmony patch target still resolves in this build, and nothing else changed.

## v3.3.0

- Update the server first, or the server and clients together, because a server still
  on 3.2.1 disconnects clients running 3.3.0.
- Drops the custom version handshake, so ServerSync's version check decides who can
  join, the same way it does for OttoPay. A client without OttoStash can join a server
  that runs it, and a client running a different OttoStash version is still turned away.
- Rebuilt against Valheim 1.0.14. Every Harmony patch target still resolves in this build, and nothing else changed.

## v3.2.1

- If you ran 3.2.0, check your settings, because a value you changed under 3.2.0 is back
  at its default. Setting names go back to the 3.1.3 spelling, such as `1 - General` and
  `Player Range`, so a config from 3.1.3 or earlier loads with its values.
- Drops the Ottomation_ModLib and Jotunn dependencies that 3.2.0 added, so OttoStash needs
  only BepInEx again.
- Keeps the favoriting tooltip text from 3.2.0, which has no apostrophe, and the README
  corrections.

## v3.2.0

- Depends on Ottomation_ModLib 1.16.0, which brings Jotunn with it. OttoStash uses the
  library for its config handling and keeps ServerSync for syncing settings, so
  `LockConfiguration` works as before.
- Config names follow the Ottomation series spelling. The numbered sections lose their
  numbers, so `1 - General` is now `General`, `1.5 - Fish` is now `Fish`, `2 - Shortcuts`
  is now `Shortcuts` and `3 - Favoriting` is now `Favoriting`. Keys lose their spaces, so
  `Player Range` is now `PlayerRange`. Configuration Manager lists the sections in the
  same order as before, unless its sort-by-name option is on.
- Your values carry over. On first load the library renames your config in place before
  OttoStash reads it, and a config carried over from AzuAutoStore goes through the same
  rename.
- The README config list now matches the file. It gains `DontStoreToBackpacks` and
  `ChestsPickupFromGround`, which it never listed, and `FishSuction` now describes what the
  setting actually does.
- The config file starts with an `_Author` section, the same as the rest of the
  Ottomation series.
- The three favoriting tooltips now say "will not be stored" in place of "won't be
  stored", because BepInEx saved the apostrophe as `\'`, which broke TOML formatters and
  syntax colors. A tooltip still on the old default changes to the new text, and a
  tooltip you wrote yourself stays as it is.

## v3.1.3

**Fixes chests not opening in 3.1.1 and 3.1.2.**

The container patch answered `Container.RPC_RequestOpen` with an RPC named
`OpenRespons`, a misspelling that Valheim 1.0 corrected to `RPC_OpenResponse`. Because
the patch suppresses the vanilla handler, the reply it sent went to an RPC that no
longer exists, the client never received the grant, and the chest stayed shut. The log
showed only `Failed to find rpc method -1556840686`, at warning level.

An RPC name is a string hashed at run time, so a stale one compiles, patches and runs
without complaint. Every RPC name in the mod was checked against the 1.0 registration
list, and this was the only stale one. The sibling stack patch already used the current
`RPC_StackResponse`.

## v3.1.2

- Rewrote the `Inventory.StackAll` transpiler so it no longer depends on the vanilla
  method's local variable layout. It stored through local slot 3 and dropped the list
  constructor, which only held while those slots stayed put, and Valheim 1.0 renumbered
  them. The filter is now spliced onto the evaluation stack, where it cannot drift.
- Favourite filtering during Stack All no longer assumes a local player exists.

## v3.1.1

**3.1.0 was effectively inert, and this release fixes the patch targets it could not
resolve.** The mod logged that it loaded, then threw out of `Harmony.PatchAll`, which
aborted every remaining patch and the rest of `Awake`, so the file watcher, the border
sprite and the MultiUserChest setup never ran. Harmony resolves these targets by name at
run time, so the compiler cannot catch a stale one.

- `ItemDrop.ItemData.GetTooltip` gained a trailing `appending` parameter. The hint is
  now also suppressed while the game builds a nested tooltip, which would otherwise
  print it twice.
- `Inventory.AddItem(ItemData, int, int, int)` gained `skipValidPositionCheck`, and three
  patches targeted the old four-parameter list.
- `Inventory.Load` now has two overloads, which made the target ambiguous, so it is
  pinned to `Load(ZPackage)`, the one containers call.
- The tooltip patch no longer assumes a local player exists.
- The ItemDrawers and QuickStack patches only apply when those mods are loaded. Their
  targets are resolved by name, so without the mod they resolved to nothing and took the
  whole PatchAll down.

## v3.1.0

- Renamed to OttoStash from AzuAutoStore 3.0.11.
- Ported to the Valheim 1.0 API. AzuAutoStore did not load at all on 1.0, because
  `ZRoutedRpc.Everybody` became a constant and the bundled ServerSync threw
  `MissingFieldException` in the plugin's static constructor.
  - Rebuilt ServerSync against the 1.0 assemblies.
  - `InventoryGrid.Element` is now the top-level `InventoryElement`, and it no
    longer carries `m_pos`.
  - `InventoryGrid.OnRightClick` and `OnLeftClick` became `OnRightDown` and
    `OnLeftDown`.
  - The private `Inventory.AddItem` overload gained a `cheated` parameter.
  - `UnityEngine.ImageConversionModule` cannot be referenced from net48, because its
    metadata names `ReadOnlySpan<byte>`, which lives in the game's Mono mscorlib. The
    `byte[]` overload of `LoadImage` still exists, so OttoStash binds it once by
    reflection and drops the reference.
- The config files are now `potto007.OttoStash.cfg` and `potto007.OttoStash.yml`.
  Your AzuAutoStore files are copied across on the first run, and an OttoStash file that
  already exists is never touched.
- The console command `azuautostoresearch` is now `ottostashsearch`.
- Rebuilt the project SDK-style, with a version-drift guard and a guard against
  repacking a version that is already tagged as published.
- New title banner and package icon.

--------------------

# AzuAutoStore release history

| `Version` | `Update Notes`                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               |
|-----------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| 3.0.11    | - Update KGItemDrawers API. <br/> - Chunked item adds to reduce some churn<br/> - Update README.md with much needed missing information.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     |
| 3.0.10    | - Add a new configuration option `Fish Suction` to `1.5 - Fish` section. When on, this will allow your ships to autostore fish (like the old bug) just by being nearby. Some people like this way of "fishing" and have requested a configuration option to allow the behaviour again. To word it a bit differently: Allow auto-storing fish that are still in water (boat 'netting'). Off = require fish to be out of the water; On = ignore IsOutOfWater() check.<br/> - Add acceptable shortcut values to the hotkeys. Been getting a lot of requests for assistance for people that insist on changing this directly in the file.<br/> - Fix some more small issues with quality checks.<br/> - Prevent some item loss scenarios that could occur.<br/> - Throttle owner requests to only try if there isn't an owner already. (which could be the chest fighting your auto-pickup). Hopefully this fixes some issues. <br/> - Compatibility with the original [ItemDrawers](https://thunderstore.io/c/valheim/p/makail/ItemDrawers/). This means this mod now supports both versions (Makail's and KG's)! <br/> - Update README and Example files with new predefined group: `Trinket` added in Call To Arms.           |
| 3.0.9     | - Fix issues with storing items of different quality when a chest is full.<br/> - Fix small issue with ownership RPC.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        |
| 3.0.8     | - Don't allow autostoring of fish unless they are out of water,<br/> - Don't allow storing singlular items unless it's from the player's inventory.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          |
| 3.0.7     | - Possibly fix an issue with the single item storage that could cause all items in your inventory to be stored. Can't remember why I coded it the way I did. Might break something, just report it if it does please.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        |
| 3.0.6     | - Fix a few bugs when teleporting or being dead.<br/>- Fix item duplication (hopefully)                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      |
| 3.0.5     | - Bug fixes and performance improvements.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    |
| 3.0.4     | - Fix for Bog Witch update.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |
| 3.0.3     | - Remove treasure prefix check, instead check creator only. <br/> - Fix containers remaining in use after storing.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           |
| 3.0.2     | - Default exclude tombstones and the player (for backpack mods) in the yml file, updated example file to match on README. If you delete the yml it will regenerate with these defaults. If you don't have them, you can now find the examples in the mod description to add them manually if needed.<br/> - Ensure that the ping effect will destroy after the allotted time, correctly.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     |
| 3.0.1     | - Fix casting issue now that I moved to interfaces for the containers.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
| 3.0.0     | - When using the vanilla Place Stacks button or the open to place stacks feature, it now respects your favorited items/slots.<br/> - Integration with Smoothbrain's Backpacks & KG's ItemDrawers. You can now store to them. There is a configuration option added to prevent storing to *any* backpacks. Found in Section 1 called "Don't Store to Backpacks"  <br/> Add in global config that prevents storing into chests from the ground when toggled off (Chests Pickup From Ground in Section 1).                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      |
| 2.1.12    | - Fix logical issue in removing invalid containers that was causing valid ones to be removed.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                |
| 2.1.11    | - If toggle.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |
| 2.1.10    | - Fix NRE that can occur when teleporting.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   |
| 2.1.9     | - Fix item loss issue with new feature.<br/> - New feature will now also tell you if the item you attempt to store is in nearby containers or not when Must Have Existing Item To Pull setting is on.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        |
| 2.1.8     | - Add in a configuration option/logic for a key that you can press (Default: Mouse2 a.k.a. Middle Click). This key, when pressed while hovering an inventory item, will store *just that item* into nearby containers.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
| 2.1.7     | - Recompile for Ashlands                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     |
| 2.1.6     | - Even more compatibility with QuickStackStore. Creating our stuff after theirs now duplicated their element under mine. I destroy the dupe now. All is well. Their update also make sure to never grab our elements. WOOT                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   |
| 2.1.5     | - Sup vikings. Fixed some issues found when this mod is installed next to QuickStackStore, we now for sure create our stuff after their mod so when they grab the first element...it's not ours! We also search for our element instead of assuming.<br/> - Additionally, fixed some issues that might cause NREs on world load.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             |
| 2.1.4     | - Salutations, Keyboard Warriors and Mouse Monarchs! It's me again, your friendly neighborhood coder (or car warranty guy if you're annoyed with me), armed with another hotfix update hotter than a graphics card in a marathon gaming session. A quirky bug where your beloved player character decided to take an unexpected permanent vacation when using AdventureBackpack alongside this mod was found. Since Goldenrevolver also had the same issue, he got me the fix as well. Shoutout to him.<br/> - But wait, there's more! I added a component that will reduce the amount of times a container is pinged. And because I know that nobody likes to be pinged over and over (looking at you, group chats), this feature has manners. It won't ping a container that's already felt the sweet ping of attention. That's one less issue to clutter your adventure.                                                                                                                                                                                                                                                                                                                                                  |
| 2.1.3     | - At this point, I should be the car warranty guy. It's me again, with a fix for another NRE caused by an optimization I made.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               |
| 2.1.2     | - Update ServerSync<br/> - Add a message for when you search for an item using the `azuautostoresearch` command. It will now tell you if something is/isn't found and how much of that something.<br/> - The search command can now be invoked simply by left clicking on an item in your inventory while holding down the SearchModifierKeybind found in the 2 - Shortcuts section.<br/> - Using the command or searching via an item in your inventory, it will now point you to the closest that contains the item you are looking for.<br/> - Now limit the searching of new items in the world causing the search to trigger in the next second...to those that are close to a container.<br/> - Add a configuration option in the 1 - General section to speed up the search interval should you wish to do that called IntervalSeconds. <br/> - Add some null checks in places they probably should have been to start with. <br/> - Probably fixed some other shit I don't remember. <br/> <br/> **Example of the new Feature:** ![](https://media0.giphy.com/media/v1.Y2lkPTc5MGI3NjExNnNzM3I2bWRnNHluZDJvY3hld3pkc3ZncDVsNXI1ZWdsZWI3Y3JxdiZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/tEDcBcOKvdbYH1he9B/source.gif) |
| 2.1.1     | - Fix NRE that can be thrown when a mob dies                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |
| 2.1.0     | - Performance improvements when storing things. It now checks more on an interval of 10 seconds. Though, if you throw out an item it will check within the next second. Also, reduced checks that might be a little expensive.<br/> - `Add in Favoriting from Goldenrevolver` By holding the Favoriting Key (default: Alt) or by using a new button, you can left click on an item to favorite it, or right click to favorite the slot it is in. This prevents most features of this mod from affecting it. No accidental quick stacking, sorting, storing or trashing. The favoriting state is shown with a custom colored border around the slot. None of the configuration options related to favoriting are synced with the server.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      |
| 2.0.3     | - Revert a small bit of code that fixes an issue.  The issue is that some items were not being added to the correct groups as expected.  <br/> - Add ElementalMagic and BloodMagic predefined categories                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     |
| 2.0.2     | - Fix Potion criteria<br/> - Fix Equipment category to include more items like it originally should have.<br/>- Add more predefined groups. I added the following  Armor, Equipment, Weapons, Shield, Chest, Legs, Shoulder, Helmet, Utility, Ammo, Arrows, and Bolts.<br/> - A file will now be created next to the dll called PredefinedGroups.txt which will contain all of the current items in the predefined groups (modded and vanilla, populates when you go into a server/world)                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    |
| 2.0.1     | - Fix some item deletion, add ability to pause the execution of storing items (LeftShift + Period by default and 10 second wait by default)<br/> - If the pausing feature doesn't work like intended, I have code queued up to potentially fix the issue. Please report bugs                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |
| 2.0.0     | - `MAJOR VERSION UPDATE`<br/> - Everything about the configuration has changed. Please delete your old config file and boot the game once with this mod installed to get a clean one.<br/> - Move as many of the configuration options that make sense to YAML configuration. Please read the mod page for details on where to find and read the file for how to use. Ask questions if you need to  in my discord. As frequent questions are asked, they will be added to the wiki tab for this mod. Read the FAQ section on the mod page for more details on that. <br/>- If you have used AzuCraftyBoxes in the past, the configuration is pretty much the same! Works the same, just in reverse (because we are storing things!)<br/> - Main difference between this and AzuCraftyBoxes configurations is that the range can be set in the yaml per container.<br/> - `TLDR;` This update breaks shit because it's a major change, if you are using the mod, delete everything (configuration file and dll). Start over. Read the mod page you lazy person...or figure it out on your own if you're not a smoothbrain                                                                                                     |
| 1.1.5     | - Update for Valheim's latest version.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
| 1.1.4     | - Small update to fix an error on server connection                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          |
| 1.1.3     | - Hildir Update                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              |
| 1.1.2     | - Updated for Valheim 0.216.9                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                |
| 1.0.2     | - Fixes that I can't remember. ALo helped find the bugs<br/> - Added a new config option to allow you to disable the chest highlight<br/> - Prevent typing your hotkey while any UI is open so you don't store your items in the chest by accident                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           |
| 1.0.1     | - AmmoNonEquipable item type missing fixed                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   |
| 1.0.0     | - Initial Release                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            |